# x

# https://www.driverscape.com/download/intel%28r%29-82567lf-gigabit-network-connection


binanc xmr 868cqGH26Uy359m8LYN7dvTshZw65T4jFC54fFdrja6aYLGxZ5kc93P9WAvb76KKR4CPYNeDxwdoXDUgDcViKTnb8NZHoqL

xmr.2miners.com:2222



https://github.com/xmrig/xmrig/releases/download/v6.20.0/xmrig-6.20.0-linux-static-x64.tar.gz



